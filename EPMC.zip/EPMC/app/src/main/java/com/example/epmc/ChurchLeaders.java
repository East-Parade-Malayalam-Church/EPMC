package com.example.epmc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ChurchLeaders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_church_leaders);
    }
}
